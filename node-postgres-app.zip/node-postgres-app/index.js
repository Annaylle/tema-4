// index.js (punctul de intrare al aplicației)

// Importăm modulele necesare
const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');
const sequelize = require('./config/db');
const userRoutes = require('./routes/userRoutes');

// Creăm aplicația Express
const app = express();

// Middleware pentru parsarea datelor JSON și a datelor din formulare
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// Servim fișierele statice din directorul "public" (frontend-ul)
app.use(express.static(path.join(__dirname, 'public')));

// Montăm rutele API sub prefixul /api
app.use('/api', userRoutes);

// Pornim sincronizarea cu baza de date și apoi serverul
const PORT = 3000;
sequelize.sync()  // sincronizează modelele cu baza de date (creează tabelul dacă nu există)
  .then(() => {
    console.log('Conexiune cu baza de date stabilită.');
    // Pornim serverul pe portul specificat
    app.listen(PORT, () => {
      console.log(`Serverul a pornit. Ascultă la http://localhost:${PORT}`);
    });
  })
  .catch(err => {
    console.error('Eroare la sincronizarea cu baza de date:', err);
  });
