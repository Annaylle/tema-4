// config/db.js
const { Sequelize } = require('sequelize');

// Inițializează o instanță Sequelize pentru conexiunea la baza de date
const sequelize = new Sequelize('myapp', 'postgres', 'Sonata12', {
  host: 'localhost',
  dialect: 'postgres'
});

// ✅ Test rapid al conexiunii
sequelize.authenticate()
  .then(() => console.log('Conexiune la baza de date reușită.'))
  .catch(err => console.error('Eroare de conectare:', err));

// Exportă instanța pentru a fi folosită în alte fișiere
module.exports = sequelize;
